<?php
define( 'ROOT_DIR', dirname(__FILE__) );
?>