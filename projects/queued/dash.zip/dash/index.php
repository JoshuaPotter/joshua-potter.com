<?php
require_once 'config.php';
?>
		<?php include(ROOT_DIR . '/views/static/header.php'); ?>
			<div id="content-container">
				<?php 
					include(ROOT_DIR . '/views/pages/content.php');
				?>
			</div>
	<?php include(ROOT_DIR . '/views/static/footer.php'); ?>