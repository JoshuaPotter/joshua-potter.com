<div class="content-container-tabs">
	<ul>
		<li><a href="#" class="active">Queue</a>
		</li>
		<li><a href="#">Suggestions</a>
		</li>
		<li><a href="#">Contributions</a>
		</li>
		<li><a href="#">Feeds</a>
		</li>
	</ul>
</div>
<h1>
	Hi there!
</h1>
<h2>
	Looks like we have sent all of your updates, share below or accept some contributions.
</h2>
<div class="share-textarea">
	<div class="share-select-accounts clearfix">
		<div class="share-account-entry">
			<a href="#" class="remove">
				x
			</a>
			<i class="fa fa-twitter social-icon"></i>
			<img src="https://farm9.staticflickr.com/8340/8260117875_67bd7d7889_s.jpg" alt="Your Icon" />
		</div>
		<div class="share-account-entry">
			<a href="#" class="remove">
				x
			</a>
			<i class="fa fa-facebook social-icon"></i>
			<img src="https://farm9.staticflickr.com/8340/8260117875_67bd7d7889_s.jpg" alt="Your Icon" />
		</div>
		<div class="share-account-entry share-account-add">
			<a href="#"></a>
		</div>
	</div>
	<textarea class="share-textarea-input" placeholder="What do you want to share?"></textarea>
	<div class="share-submission">
		<div class="row">
			<div class="col-md-4 share-attachment">
				<i class="fa fa-image fa-2x"></i>
			</div>
			<div class="col-md-8 share-btns">
				<span class="character-counter">140</span>
				<a href="#" class="btn btn-split">Split</a>
				<a href="#" class="btn btn-primary">Share Now</a>
				<a href="#" class="btn btn-secondary">Schedule</a>
			</div>
		</div>
	</div>
</div>
