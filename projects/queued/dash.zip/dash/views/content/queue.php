<div class="content-timeline">
	<div class="content-timeline-wrapper">
		<div class="date">
			<span class="dot"></span>
			<span class="relative-date">Today</span> - 21 March
		</div>
		<div class="post link clearfix">
			<span class="type">
				<i class="fa fa-chain"></i>
			</span>
			<div class="post-box">
				<div class="post-wrapper">
					<div class="post-content">
						<p>
							5 reasons it's time for a 4-day work week <a href="#" target="_blank">http://buff.ly/1qu4nAc</a>
						</p>
					</div>
					<div class="post-footer">
						<span class="time"><i class="fa fa-clock-o"></i> 8:45pm</span>
						<span class="actions">
							<a href="#"><i class="fa fa-trash"></i></a>
							<a href="#"><i class="fa fa-pencil"></i></a>
							<a href="#"><i class="fa fa-sort"></i></a>
							<a href="#"><i class="fa fa-external-link"></i></a>
						</span>
					</div>
				</div>
			</div>
		</div>
		<div class="post image clearfix">
			<span class="type">
				<i class="fa fa-image"></i>
			</span>
			<div class="post-box clearfix">
				<div class="post-wrapper">
					<div class="post-content">
						<p>
							Amazon updates their login screen for the first time in a decade <a href="#" target="_blank">http://buff.ly/1qu4nAc</a>
						</p>
					</div>
					<div class="post-footer">
						<span class="time"><i class="fa fa-clock-o"></i> 8:45pm</span>
						<span class="actions">
							<a href="#"><i class="fa fa-trash"></i></a>
							<a href="#"><i class="fa fa-pencil"></i></a>
							<a href="#"><i class="fa fa-sort"></i></a>
							<a href="#"><i class="fa fa-external-link"></i></a>
						</span>
					</div>
				</div>
				<a href="#" class="post-image" style="background-image: url('https://farm6.staticflickr.com/5467/9993837063_746a23ea45_b.jpg');"></a>
			</div>
		</div>
		<div class="date">
			<span class="dot"></span>
			<span class="relative-date">Tomorrow</span> - 22 March
		</div>
		<div class="post link clearfix">
			<span class="type">
				<i class="fa fa-chain"></i>
			</span>
			<div class="post-box">
				<div class="post-wrapper">
					<div class="post-content">
						<p>
							5 reasons it's time for a 4-day work week <a href="#" target="_blank">http://buff.ly/1qu4nAc</a>
						</p>
					</div>
					<div class="post-footer">
						<span class="time"><i class="fa fa-clock-o"></i> 8:45pm</span>
						<span class="actions">
							<a href="#"><i class="fa fa-trash"></i></a>
							<a href="#"><i class="fa fa-pencil"></i></a>
							<a href="#"><i class="fa fa-sort"></i></a>
							<a href="#"><i class="fa fa-external-link"></i></a>
						</span>
					</div>
				</div>
			</div>
		</div>
		<div class="post image clearfix">
			<span class="type">
				<i class="fa fa-image"></i>
			</span>
			<div class="post-box clearfix">
				<div class="post-wrapper">
					<div class="post-content">
						<p>
							Amazon updates their login screen for the first time in a decade <a href="#" target="_blank">http://buff.ly/1qu4nAc</a>
						</p>
					</div>
					<div class="post-footer">
						<span class="time"><i class="fa fa-clock-o"></i> 8:45pm</span>
						<span class="actions">
							<a href="#"><i class="fa fa-trash"></i></a>
							<a href="#"><i class="fa fa-pencil"></i></a>
							<a href="#"><i class="fa fa-sort"></i></a>
							<a href="#"><i class="fa fa-external-link"></i></a>
						</span>
					</div>
				</div>
				<a href="#" class="post-image" style="background-image: url('https://farm6.staticflickr.com/5467/9993837063_746a23ea45_b.jpg');"></a>
			</div>
		</div>
	</div>
</div>