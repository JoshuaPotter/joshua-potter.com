<div class="content-container-tabs">
	<ul>
		<li><a href="#" class="active">Queue</a>
		</li>
		<li><a href="#">Suggestions</a>
		</li>
		<li><a href="#">Contributions</a>
		</li>
		<li><a href="#">Feeds</a>
		</li>
	</ul>
</div>
<div class="row share-split">
	<div class="col-md-6">
		<div class="share-textarea">
			<div class="share-select-accounts clearfix">
				<div class="share-account-entry">
					<a href="#" class="remove">
						x
					</a>
					<i class="fa fa-twitter social-icon"></i>
					<img src="https://farm9.staticflickr.com/8340/8260117875_67bd7d7889_s.jpg" alt="Your Icon" />
				</div>
				<div class="share-account-entry share-account-add">
					<a href="#"></a>
				</div>
			</div>
			<textarea class="share-textarea-input" placeholder="What do you want to share?"></textarea>
			<div class="share-submission">
				<div class="row">
					<div class="col-md-4 share-attachment">
						<i class="fa fa-image fa-2x"></i>
					</div>
					<div class="col-md-8 share-btns">
						<span class="character-counter">140</span>
						<a href="#" class="btn btn-primary"><i class="fa fa-external-link"></i></a>
						<a href="#" class="btn btn-secondary"><i class="fa fa-clock-o"></i></a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-6">
		<div class="share-textarea">
			<div class="share-select-accounts clearfix">
				<div class="share-account-entry">
					<a href="#" class="remove">
						x
					</a>
					<i class="fa fa-facebook social-icon"></i>
					<img src="https://farm9.staticflickr.com/8340/8260117875_67bd7d7889_s.jpg" alt="Your Icon" />
				</div>
				<div class="share-account-entry share-account-add">
					<a href="#"></a>
				</div>
			</div>
			<textarea class="share-textarea-input" placeholder="What do you want to share?"></textarea>
			<div class="share-submission">
				<div class="row">
					<div class="col-md-4 share-attachment">
						<i class="fa fa-image fa-2x"></i>
					</div>
					<div class="col-md-8 share-btns">
						<a href="#" class="btn btn-primary"><i class="fa fa-external-link"></i></a>
						<a href="#" class="btn btn-secondary"><i class="fa fa-clock-o"></i></a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
