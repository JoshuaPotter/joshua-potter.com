<?php 
	include '../../config.php';
	include ROOT_DIR . '/views/content/queue-share-split.php';
	include ROOT_DIR . '/views/content/queue.php'; 
?>