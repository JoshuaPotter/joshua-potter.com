<?php 
	include '../../config.php';
	include ROOT_DIR . '/views/content/queue-analytics-analysis.php';
?>